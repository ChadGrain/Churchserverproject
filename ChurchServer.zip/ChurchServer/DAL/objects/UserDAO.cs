﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.objects
{
   public class UserDAO
    {
        public int UserID;
        public string Username;
        public string Password;
        public string Firstname;
        public string Lastname;
        public string Address;
        public int RoleID;
        public string RoleName;

    }
}
